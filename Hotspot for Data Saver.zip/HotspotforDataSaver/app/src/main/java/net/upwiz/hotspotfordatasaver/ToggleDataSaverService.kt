package net.upwiz.hotspotfordatasaver

import android.service.quicksettings.TileService

class ToggleDataSaverService : TileService() {
    override fun onTileAdded() {
        // Handle the tile being added to the Quick Settings panel
    }

    override fun onTileRemoved() {
        // Handle the tile being removed from the Quick Settings panel
    }

    override fun onClick() {
        // Handle the tile being clicked
    }

}